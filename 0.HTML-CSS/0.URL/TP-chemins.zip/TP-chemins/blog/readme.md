# TP sur les url

Le dossier `blog` et ses sous-dossiers contienent 5 fichiers HTML.
Dans chacun de ces fichiers HTML, en utilisant des url à chemins relatifs:
- Corriger l'url de tous les liens
- Corriger l'url de l'image

S'il vous reste du temps:
- Corriger l'url de la favicon `icon.png`.
- corriger l'url du fichier `style.css`
